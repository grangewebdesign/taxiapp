const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect('mongodb://localhost:27017/driver-hours', {
  useNewUrlParser: true,
  useUnifiedTopology: true,
});

const entrySchema = new mongoose.Schema({
  name: String,
  days: Number,
  hours: Number,
  weekStart: String,
  createdAt: { type: Date, default: Date.now },
});

const Entry = mongoose.model('Entry', entrySchema);

app.post('/api/entry', async (req, res) => {
  const { name, days, hours, weekStart } = req.body;
  const newEntry = new Entry({ name, days, hours, weekStart });
  await newEntry.save();
  res.status(201).json({ message: 'Entry saved' });
});

app.get('/api/entries/:weekStart', async (req, res) => {
  const { weekStart } = req.params;
  const entries = await Entry.find({ weekStart });
  res.json(entries);
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
