import React, { useEffect, useState } from 'react';
import axios from 'axios';

function formatDate(date) {
  return date.toISOString().split('T')[0];
}

function getStartOfWeek(date) {
  const d = new Date(date);
  const day = d.getDay();
  const diff = d.getDate() - day + (day === 0 ? -6 : 1);
  d.setDate(diff);
  return d;
}

export default function OwnerDashboard() {
  const [weekStart, setWeekStart] = useState(getStartOfWeek(new Date()));
  const [entries, setEntries] = useState([]);

  const fetchEntries = async () => {
    const iso = formatDate(weekStart);
    const res = await axios.get(`http://localhost:5000/api/entries/${iso}`);
    setEntries(res.data);
  };

  useEffect(() => {
    fetchEntries();
  }, [weekStart]);

  return (
    <div style={{ maxWidth: '600px', margin: 'auto' }}>
      <h2>Owner Dashboard</h2>
      <div>
        <button onClick={() => setWeekStart(new Date(weekStart.setDate(weekStart.getDate() - 7)))}>← Previous</button>
        <span style={{ margin: '0 1rem' }}>{formatDate(weekStart)}</span>
        <button onClick={() => setWeekStart(new Date(weekStart.setDate(weekStart.getDate() + 7)))}>Next →</button>
      </div>
      <table style={{ width: '100%', marginTop: '1rem', borderCollapse: 'collapse' }}>
        <thead>
          <tr><th>Name</th><th>Days</th><th>Hours</th></tr>
        </thead>
        <tbody>
          {entries.map((e, i) => (
            <tr key={i}>
              <td>{e.name}</td>
              <td>{e.days}</td>
              <td>{e.hours}</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
