import React, { useState } from 'react';
import axios from 'axios';

function getWeekStartISO() {
  const today = new Date();
  const day = today.getDay();
  const diff = today.getDate() - day + (day === 0 ? -6 : 1);
  const monday = new Date(today.setDate(diff));
  return monday.toISOString().split('T')[0];
}

export default function DriverForm() {
  const [name, setName] = useState('');
  const [days, setDays] = useState(0.5);
  const [success, setSuccess] = useState(false);
  const weekStart = getWeekStartISO();

  const handleSubmit = async (e) => {
    e.preventDefault();
    const hours = days * 8;
    await axios.post('http://localhost:5000/api/entry', {
      name,
      days,
      hours,
      weekStart
    });
    setSuccess(true);
    setName('');
    setDays(0.5);
  };

  return (
    <div style={{ maxWidth: '400px', margin: 'auto' }}>
      <h2>Driver Entry</h2>
      <p>Week starting: {weekStart}</p>
      <form onSubmit={handleSubmit}>
        <label>Name</label>
        <input value={name} onChange={(e) => setName(e.target.value)} required />
        <label>Days</label>
        <select value={days} onChange={(e) => setDays(parseFloat(e.target.value))}>
          {[...Array(10)].map((_, i) => {
            const val = (i + 1) * 0.5;
            return <option key={val} value={val}>{val} days</option>;
          })}
        </select>
        <button type="submit">Submit</button>
        {success && <p style={{ color: 'green' }}>Submitted!</p>}
      </form>
    </div>
  );
}
